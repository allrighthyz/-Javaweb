create definer = root@localhost trigger stuLogin
    after delete
    on student
    for each row
begin 
delete from user where user_num=old.stu_num;
end;

