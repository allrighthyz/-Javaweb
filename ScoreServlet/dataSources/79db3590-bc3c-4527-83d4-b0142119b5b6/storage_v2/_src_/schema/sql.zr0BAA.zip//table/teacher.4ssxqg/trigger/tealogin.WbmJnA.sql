create definer = root@localhost trigger teaLogin
    after delete
    on teacher
    for each row
begin
delete from user where user_num=old.tea_num;
end;

